<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ad;
use DB;

class UserController extends Controller
{
    public function postad(Request $request)
    {
        $postad = new ad;
        $request->validate([
            'name' => 'required',
            'address' => 'required',
            'ph' => 'required',
            'pinfo' => 'required',
            'pname' => 'required',
            'price' => 'required',
            'brand' => 'required',
            'type' => 'required',
        ]);

        $postad->name = $request->name;
        $postad->address = $request->address;
        $postad->ph = $request->ph;
        $postad->pinfo = $request->pinfo;
        $postad->pname = $request->pname;
        $postad->price = $request->price;
        $postad->brand = $request->brand;
        $postad->type = $request->type;

        $postad->save();

        return redirect('/')->with('success','Your AD was Successfully stored');
    }
    
    public function view()
    {
        $select = ad::all();
        return view('/view', compact('select'));
    }
    public function ascending()
    {
        $select = ad::orderBy('name', 'ASC')->get();
        return view('/view', compact('select'));
    }
    public function descending()
    {
        $select = ad::orderBy('name', 'DESC')->get();
        return view('/view', compact('select'));
    }
    public function ascprice()
    {
        $select = ad::orderBy('price', 'ASC')->get();
        return view('/view', compact('select'));
    }
    public function descprice()
    {
        $select = ad::orderBy('price', 'DESC')->get();
        return view('/view', compact('select'));
    }
}
