<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>

        <style>
            body 
            {
                font-family : 'Georgia';
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-light bg-primary">
            <span class="navbar-brand" style="font-size: 70px;font-weight:bolder">
                <img src="{{ URL::asset('public/images/images.png') }} " style="margin-left: 5%" width="100" height="100" class="d-inline-block align-top" alt="">
                Mobile Classifieds</span>
                <a href="{{ url('/') }}">
                    <button type="button" class="btn btn-primary">Back</button>
                </a>
        </nav>
            <br><br><br>
            <a href="{{ url('/ascen') }}">
                <button type="button" class="btn btn-primary">Ascending by Name</button>
            </a>
            
            <a href="{{ url('/desc') }}" >
                <button type="button" class="btn btn-primary">Descending by Name</button>
            </a>
            <table style="float:right;">
                <tr>
                    <td>
                        <a href="{{ url('/ascenprice') }}" >
                            <button type="button" class="btn btn-primary">Ascending by Price</button>
                        </a>
                    </td>
                    <td>
                        <a href="{{ url('/descprice') }}" >
                            <button type="button" class="btn btn-primary">Descending by Price</button>
                        </a>
                    </td>
                </tr>
            </table>
        <table border="1" class="table">
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Product Info</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Brand</th>
                <th>Type</th>
            </tr>
            @foreach($select as $ad)
            <tr>
                <td>{{ $ad->name }}</td>
                <td>{{ $ad->address }}</td>
                <td>{{ $ad->ph }}</td>
                <td>{{ $ad->pinfo }}</td>
                <td>{{ $ad->pname }}</td>
                <td>{{ $ad->price }}</td>
                <td>{{ $ad->brand }}</td>
                <td>{{ $ad->type }}</td>
            </tr>
            @endforeach
        </table>
        </body>
