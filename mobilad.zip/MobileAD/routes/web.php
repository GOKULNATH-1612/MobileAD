<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::post('/postdb', 'App\Http\Controllers\UserController@postad');

Route::get('/postad', function(){
    return view('post');
});

Route::get('/viewad', 'App\Http\Controllers\UserController@view');

Route::get('/ascen', 'App\Http\Controllers\UserController@ascending');

Route::get('/desc', 'App\Http\Controllers\UserController@descending');

Route::get('/ascenprice', 'App\Http\Controllers\UserController@ascprice');

Route::get('/descprice', 'App\Http\Controllers\UserController@descprice');