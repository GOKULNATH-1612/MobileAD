<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>

        <style>
            body 
            {
                font-family : 'Georgia';
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-light bg-primary">
            <span class="navbar-brand" style="font-size: 70px;font-weight:bolder">
                <img src="<?php echo e(URL::asset('public/images/images.png')); ?> " style="margin-left: 5%" width="100" height="100" class="d-inline-block align-top" alt="">
                Mobile Classifieds</span>
            <a href="<?php echo e(url('/')); ?>">
                <button type="button" class="btn btn-primary">Back</button>
            </a>
        </nav>
        <br><br><br>
        <h3 style="margin-left: 20%;font-weight:bold;font-size: 50px">Seller Info</h3>
        <fieldset style="margin-left: 20%;top:15%;width: 50%;"> 
        <form action="postdb" method="post" class="form">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="margin: 5%">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" placeholder="Enter Name">
                
            </div>
            <div class="form-group" style="margin: 5%">
                <label for="address">Full Address</label>
                <textarea class="form-control" name="address" rows="3"></textarea>
            </div>
            <div class="form-group" style="margin: 5%">
                <label for="ph">Phone</label>
                <input type="number" class="form-control" name="ph" placeholder="Enter Phone">
                
            </div>
            <div class="form-group" style="margin: 5%">
                <label for="pinfo">Product Info</label>
                <input type="text" class="form-control" name="pinfo" placeholder="Enter Product Info">
                
            </div>
            <div class="form-group" style="margin: 5%">
                <label for="pname">Product Name</label>
                <input type="text" class="form-control" name="pname" placeholder="Enter Product Name">
                
            </div>
            <div class="form-group" style="margin: 5%"> 
                <label for="price">Price</label>
                <input type="number" class="form-control" name="price" placeholder="Enter Price">
                
            </div>
            <div class="form-group" style="margin: 5%">
                <label for="brand">Brand</label>
                <input type="text" class="form-control" name="brand" placeholder="Enter Brand">
            </div>
            <div class="form-group" style="margin: 5%">
            <label for="type">Type</label>
                <select class="form-select" name="type" aria-label="Default select example">
                    <option selected>...</option>
                    <option value="new">New</option>
                    <option value="used">Used</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="margin: 5%">Submit</button>
        </form>
        </fieldset>
        
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\MobileAD\resources\views/post.blade.php ENDPATH**/ ?>