<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>

        <style>
            body 
            {
                font-family : 'Georgia';
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-light bg-primary">
            <span class="navbar-brand" style="font-size: 70px;font-weight:bolder">
                <img src="<?php echo e(URL::asset('public/images/images.png')); ?> " style="margin-left: 5%" width="100" height="100" class="d-inline-block align-top" alt="">
                Mobile Classifieds</span>
                <a href="<?php echo e(url('/')); ?>">
                    <button type="button" class="btn btn-primary">Back</button>
                </a>
        </nav>
            <br><br><br>
            <a href="<?php echo e(url('/ascen')); ?>">
                <button type="button" class="btn btn-primary">Ascending by Name</button>
            </a>
            
            <a href="<?php echo e(url('/desc')); ?>" >
                <button type="button" class="btn btn-primary">Descending by Name</button>
            </a>
            <table style="float:right;">
                <tr>
                    <td>
                        <a href="<?php echo e(url('/ascenprice')); ?>" >
                            <button type="button" class="btn btn-primary">Ascending by Price</button>
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(url('/descprice')); ?>" >
                            <button type="button" class="btn btn-primary">Descending by Price</button>
                        </a>
                    </td>
                </tr>
            </table>
        <table border="1" class="table">
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Product Info</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Brand</th>
                <th>Type</th>
            </tr>
            <?php $__currentLoopData = $select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ad->name); ?></td>
                <td><?php echo e($ad->address); ?></td>
                <td><?php echo e($ad->ph); ?></td>
                <td><?php echo e($ad->pinfo); ?></td>
                <td><?php echo e($ad->pname); ?></td>
                <td><?php echo e($ad->price); ?></td>
                <td><?php echo e($ad->brand); ?></td>
                <td><?php echo e($ad->type); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </body>
<?php /**PATH C:\xampp\htdocs\MobileAD\resources\views//view.blade.php ENDPATH**/ ?>